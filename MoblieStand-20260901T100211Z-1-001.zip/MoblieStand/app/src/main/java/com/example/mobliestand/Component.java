package com.example.mobliestand;

public class Component {
    private int id;
    private String name;
    private String description;
    private int imageResource;
    private int arduinoPin;

    public Component() {}

    public Component(String name, String description, int imageResource, int arduinoPin) {
        this.name = name;
        this.description = description;
        this.imageResource = imageResource;
        this.arduinoPin = arduinoPin;
    }

    // Геттеры/сеттеры
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public int getImageResource() { return imageResource; }
    public void setImageResource(int imageResource) { this.imageResource = imageResource; }
    public int getArduinoPin() { return arduinoPin; }
    public void setArduinoPin(int arduinoPin) { this.arduinoPin = arduinoPin; }
}