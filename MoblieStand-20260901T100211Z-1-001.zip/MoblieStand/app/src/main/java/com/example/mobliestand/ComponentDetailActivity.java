package com.example.mobliestand;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ComponentDetailActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_component_detail);
        int id = getIntent().getIntExtra("COMPONENT_ID", -1);
        if (id == -1) { finish(); return; }

        DatabaseHelper db = new DatabaseHelper(this);
        Component c = db.getComponentById(id);
        if (c == null) { finish(); return; }

        ((ImageView)findViewById(R.id.ivComponent)).setImageResource(c.getImageResource());
        ((TextView)findViewById(R.id.tvName)).setText(c.getName());
        ((TextView)findViewById(R.id.tvDescription)).setText(c.getDescription());

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        findViewById(R.id.btnExit).setOnClickListener(v -> {
            Intent i = new Intent(this, LoginActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            finish();
        });
    }
}