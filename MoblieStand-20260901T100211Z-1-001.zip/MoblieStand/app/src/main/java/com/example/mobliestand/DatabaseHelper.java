package com.example.mobliestand;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "MobileStandDB";
    private static final int DB_VERSION = 1;

    private static final String TABLE_COMPONENTS = "components";
    private static final String KEY_ID = "id";
    private static final String KEY_NAME = "name";
    private static final String KEY_DESC = "description";
    private static final String KEY_IMAGE = "image";
    private static final String KEY_PIN = "arduino_pin";

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_COMPONENTS + " (" +
                KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                KEY_NAME + " TEXT, " +
                KEY_DESC + " TEXT, " +
                KEY_IMAGE + " INTEGER, " +
                KEY_PIN + " INTEGER)");
        addDefaultComponents(db);
    }

    private void addDefaultComponents(SQLiteDatabase db) {
        // 1. Компоненты стенда (8 шт.)
        insertComponent(db, "Камера", "Основной модуль для фото- и видеосъёмки. Состоит из объектива, матрицы и системы автофокусировки.", R.drawable.ic_camera, 4);
        insertComponent(db, "Материнская плата", "Главная печатная плата, соединяющая все компоненты. На ней размещены процессор, память, контроллеры.", R.drawable.ic_motherboard, 5);
        insertComponent(db, "Динамик", "Электроакустический преобразователь для воспроизведения звука. Используется в разговорах и мультимедиа.", R.drawable.ic_speaker, 6);
        insertComponent(db, "Корпусные элементы", "Задняя крышка, рамка, кнопки громкости и включения. Защищают внутренние компоненты и придают форму.", R.drawable.ic_body, 7);
        insertComponent(db, "Аккумулятор", "Литий-ионный источник питания. Обеспечивает автономную работу устройства.", R.drawable.ic_battery, 8);
        insertComponent(db, "Клавиатура", "Блок физических кнопок для ввода текста и цифр. Включает функциональные клавиши.", R.drawable.ic_keyboard, 9);
        insertComponent(db, "Дисплей", "LCD или OLED экран для отображения интерфейса и контента. Основной орган взаимодействия с пользователем.", R.drawable.ic_display, 10);
        insertComponent(db, "Сенсорный экран", "Прозрачная панель поверх дисплея, реагирующая на касания пальцев. Обеспечивает управление жестами.", R.drawable.ic_touchscreen, 11);

        // 2. Внутренние компоненты смартфона
        insertComponent(db, "Процессор (CPU)", "Центральный процессор, выполняет основные вычисления. Состоит из ядер (Cortex-A, Kryo и др.). Тактовая частота влияет на скорость работы.", R.drawable.ic_cpu, 12);
        insertComponent(db, "Графический ускоритель (GPU)", "Отвечает за обработку графики и вывод изображения на экран. Необходим для игр и плавного интерфейса.", R.drawable.ic_gpu, 13);
        insertComponent(db, "Оперативная память (RAM)", "Временное хранилище данных для запущенных приложений. Большой объём позволяет держать больше программ в фоне.", R.drawable.ic_ram, 14);
        insertComponent(db, "Флеш-память (ROM/Storage)", "Постоянная память для ОС, приложений и файлов пользователя. Измеряется в гигабайтах.", R.drawable.ic_storage, 15);
        insertComponent(db, "Модем и приёмопередатчик", "Модуль сотовой связи (4G/5G), обеспечивающий звонки и мобильный интернет.", R.drawable.ic_modem, 16);
        insertComponent(db, "Wi-Fi/Bluetooth модуль", "Чип беспроводной связи для подключения к сетям Wi-Fi и обмена данными с гарнитурами.", R.drawable.ic_wifi_bt, 17);
        insertComponent(db, "NFC-контроллер", "Обеспечивает связь на малых расстояниях (до 10 см). Используется для бесконтактной оплаты.", R.drawable.ic_nfc, 18);
        insertComponent(db, "Разъём питания и данных", "USB-C, microUSB или Lightning. Для зарядки и передачи данных.", R.drawable.ic_usb, 19);
        insertComponent(db, "Слот SIM-карты и SD-карты", "Посадочные места для SIM-карт и карты памяти microSD.", R.drawable.ic_sim, 20);
        insertComponent(db, "Датчики (сенсоры)", "Акселерометр, гироскоп, датчик освещённости, приближения, компас. Определяют ориентацию и внешние условия.", R.drawable.ic_sensors, 21);
        insertComponent(db, "Вибромотор", "Микродвигатель с эксцентриком, создающий вибрацию для уведомлений и тактильного отклика.", R.drawable.ic_vibrator, 22);
        insertComponent(db, "Разъём для наушников 3.5 мм", "Аналоговый аудиовыход для подключения проводных наушников. В новых моделях может отсутствовать.", R.drawable.ic_headphone_jack, 23);

        // 3. Другие мобильные устройства
        insertComponent(db, "Ноутбук", "Портативный компьютер с аккумулятором, клавиатурой и дисплеем. Включает те же компоненты, что и смартфон, но в более крупном корпусе.", R.drawable.ic_laptop, 24);
        insertComponent(db, "Планшетный компьютер", "Устройство с большим сенсорным экраном (7-12 дюймов). Архитектура аналогична смартфону.", R.drawable.ic_tablet, 25);
        insertComponent(db, "Умные часы (Smart Watch)", "Носимое устройство на запястье с процессором, дисплеем, датчиками пульса и Bluetooth.", R.drawable.ic_smartwatch, 26);
        insertComponent(db, "Фитнес-браслет", "Носимое устройство для отслеживания активности и здоровья. Обычно имеет шагомер, датчик пульса и небольшой дисплей.", R.drawable.ic_fitnessband, 27);
    }

    private void insertComponent(SQLiteDatabase db, String name, String desc, int imageRes, int pin) {
        ContentValues values = new ContentValues();
        values.put(KEY_NAME, name);
        values.put(KEY_DESC, desc);
        values.put(KEY_IMAGE, imageRes);
        values.put(KEY_PIN, pin);
        db.insert(TABLE_COMPONENTS, null, values);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_COMPONENTS);
        onCreate(db);
    }

    public List<Component> getAllComponents() {
        List<Component> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_COMPONENTS + " ORDER BY " + KEY_ID + " ASC", null);
        if (cursor.moveToFirst()) {
            do {
                Component c = new Component();
                c.setId(cursor.getInt(cursor.getColumnIndexOrThrow(KEY_ID)));
                c.setName(cursor.getString(cursor.getColumnIndexOrThrow(KEY_NAME)));
                c.setDescription(cursor.getString(cursor.getColumnIndexOrThrow(KEY_DESC)));
                c.setImageResource(cursor.getInt(cursor.getColumnIndexOrThrow(KEY_IMAGE)));
                c.setArduinoPin(cursor.getInt(cursor.getColumnIndexOrThrow(KEY_PIN)));
                list.add(c);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return list;
    }

    public Component getComponentById(int id) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_COMPONENTS + " WHERE " + KEY_ID + "=?", new String[]{String.valueOf(id)});
        if (cursor.moveToFirst()) {
            Component c = new Component();
            c.setId(cursor.getInt(cursor.getColumnIndexOrThrow(KEY_ID)));
            c.setName(cursor.getString(cursor.getColumnIndexOrThrow(KEY_NAME)));
            c.setDescription(cursor.getString(cursor.getColumnIndexOrThrow(KEY_DESC)));
            c.setImageResource(cursor.getInt(cursor.getColumnIndexOrThrow(KEY_IMAGE)));
            c.setArduinoPin(cursor.getInt(cursor.getColumnIndexOrThrow(KEY_PIN)));
            cursor.close();
            return c;
        }
        cursor.close();
        return null;
    }
}