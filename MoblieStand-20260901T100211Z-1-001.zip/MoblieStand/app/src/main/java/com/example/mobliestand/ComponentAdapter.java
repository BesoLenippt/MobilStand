package com.example.mobliestand;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.util.List;

public class ComponentAdapter extends ArrayAdapter<Component> {
    private Context context;
    private List<Component> components;

    public ComponentAdapter(Context context, List<Component> components) {
        super(context, R.layout.item_component, components);
        this.context = context;
        this.components = components;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.item_component, parent, false);
        }

        Component component = components.get(position);
        ((ImageView) convertView.findViewById(R.id.component_image)).setImageResource(component.getImageResource());
        ((TextView) convertView.findViewById(R.id.component_name)).setText(component.getName());
        ((TextView) convertView.findViewById(R.id.component_description)).setText(component.getDescription());

        return convertView;
    }
}