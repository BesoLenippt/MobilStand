package com.example.mobliestand;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        findViewById(R.id.btnStudentLogin).setOnClickListener(v ->
                startActivity(new Intent(this, StudentActivity.class)));

        findViewById(R.id.btnAbout).setOnClickListener(v -> {
            Dialog d = new Dialog(this);
            d.setContentView(R.layout.dialog_about);
            ((TextView)d.findViewById(R.id.tvDeveloperName)).setText("Корчагина Анастасия Владимировна");
            ((TextView)d.findViewById(R.id.tvDeveloperEmail)).setText("korchagina.nastena@list.ru");
            d.findViewById(R.id.btnClose).setOnClickListener(v2 -> d.dismiss());
            d.show();
        });

        findViewById(R.id.btnExit).setOnClickListener(v -> finishAffinity());
    }
}