package com.example.mobliestand;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;

public class StudentActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student);

        ListView lv = findViewById(R.id.listViewComponents);
        DatabaseHelper db = new DatabaseHelper(this);
        ComponentAdapter adapter = new ComponentAdapter(this, db.getAllComponents());
        lv.setAdapter(adapter);
        lv.setOnItemClickListener((p, v, pos, id) -> {
            Component c = (Component) p.getItemAtPosition(pos);
            startActivity(new Intent(this, ComponentDetailActivity.class)
                    .putExtra("COMPONENT_ID", c.getId()));
        });
    }
}